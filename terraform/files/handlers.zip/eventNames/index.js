module.exports = {
    CREATE: 'create'
};